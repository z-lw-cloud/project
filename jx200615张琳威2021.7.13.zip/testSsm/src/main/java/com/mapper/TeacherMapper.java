package com.mapper;

import com.pojo.Teacher;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @version 1.0
 * @author: William
 * @date: 2021/7/13 0:32
 * @desc:
 */
@Mapper
@Repository
public interface TeacherMapper {
    List<Teacher> queryAllTeacher();
}
