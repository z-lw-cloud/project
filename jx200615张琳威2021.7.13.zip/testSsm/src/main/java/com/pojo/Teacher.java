package com.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @version 1.0
 * @author: William
 * @date: 2021/7/13 0:10
 * @desc:
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Teacher {
    private String TId;
    private String TName;
}
