package com.controller;

import com.mapper.TeacherMapper;
import com.pojo.Teacher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @version 1.0
 * @author: William
 * @date: 2021/7/13 0:46
 * @desc:
 */
@RestController
public class TeacherController {
    @Autowired
    private TeacherMapper teacherMapper;

    @GetMapping("/teacher")
    public List<Teacher> queryTeacher(){
        List<Teacher> teacherList=teacherMapper.queryAllTeacher();
        System.out.println(teacherList);
        return teacherList;
    }
}
